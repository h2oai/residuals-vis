package alerts;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.support.PagedListHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AlertController {

    @Value("${numAlerts}")
    String numAlertsString;

    @RequestMapping("/api/alerts")
    public List<Alert> getAlerts() {

        int numAlerts;
        if (numAlertsString == null)
        {
            numAlerts = 40;
        }
        else
        {
            numAlerts = Integer.parseInt(numAlertsString);
        }
        List<Alert> alerts = new ArrayList<>();
        for (int i = 0; i < numAlerts; i++) {
            alerts.add(new Alert());
        }
        return alerts;
    }
}
