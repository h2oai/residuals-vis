package alerts;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;



public class Alert {

    private String alertId;

    private String alertName;

    private String owner;

    private int priority = 0;

    private int status = 0;

    private String comments;

    private String updatedUserId;

    private String updatedTimestamp;

    public Alert() {
        SecureRandom random = new SecureRandom();
        alertId = new BigInteger(130, random).toString(32);
        alertName = alertNameGenerator();
        priority = priorityGenerator();
        owner = eidGenerator();
        status = statusGenerator();
        comments = "This Alert has comments";
        updatedUserId = eidGenerator();
        updatedTimestamp = timestampGenerator("2016-04-09 00:00:00", "2013-04-09 23:59:59").toString();
    }

    public String getAlertId() {
        return alertId;
    }

    public String getAlertName() {
        return alertName;
    }

    public String getOwner() {
        return owner;
    }

    public int getPriority() {
        return priority;
    }

    public int getStatus() {
        return status;
    }

    public String getComments() {
        return comments;
    }

    public String getUpdatedUserId() {
        return updatedUserId;
    }

    public String getUpdatedTimestamp() {
        return updatedTimestamp;
    }

    private String alertNameGenerator() {
        String randomAlertName = "";
        double randomNumber = Math.random();
        if (randomNumber < .2)
        {
            randomAlertName += "Email Alert from ";
        }
        else if (randomNumber < .4)
        {
            randomAlertName += "Ironport Alert from ";
        }
        else if (randomNumber < .6)
        {
            randomAlertName += "Bluecoat Alert from ";
        }
        else if (randomNumber < .8)
        {
            randomAlertName += "Fireye Alert from ";
        }
        else {
            randomAlertName += "Syslog Alert from ";
        }

        Random r = new Random();
        randomAlertName += r.nextInt(256) + "." + r.nextInt(256) + "." + r.nextInt(256) + "." + r.nextInt(256);
        return randomAlertName;
    }

    private Timestamp timestampGenerator(String startTime, String endTime) {
        long offset = Timestamp.valueOf(startTime).getTime();
        long end = Timestamp.valueOf(endTime).getTime();
        long diff = end - offset + 1;
        return new Timestamp(offset + (long)(Math.random() * diff));
    }

    private int priorityGenerator() {
        double randomNumber = Math.random();
        if (randomNumber < .35) {
            return 1;
        } else if (randomNumber < .65) {
            return 2;
        } else if (randomNumber < .80) {
            return 3;
        } else if (randomNumber < .92) {
            return 4;
        } else {
            return 5;
        }
    }

    private String eidGenerator() {
        double randomNumber = Math.random();
        if (randomNumber < .2)
        {
            return "abc123";
        }
        else if (randomNumber < .4)
        {
            return "zhh228";
        }
        else if (randomNumber < .6)
        {
            return "ldj892";
        }
        else if (randomNumber < .8)
        {
            return "sld088";
        }
        else {
            return "aks993";
        }
    }

    private int statusGenerator() {
        double randomNumber = Math.random();
        if (randomNumber < .25)
        {
            return 1;
        }
        else if (randomNumber < .5)
        {
            return 2;
        }
        else if (randomNumber < .75)
        {
            return 3;
        }
        else {
            return 4;
        }
    }
}
